<?php
    @$keywords=$_GET["keywords"];
    @$valider=$_GET[ "valider" ];
    if(isset ($valider) && !empty (trim($keywords ) ) ) {
        $words=explode(" ", trim($keywords ) ) ;
        for ( $i=0; $i<count($words );$i++)
            $kw[$i]="Titre like '%".$words[$i]."%'";
        $bdd = new PDO( 'mysql:host=localhost; dbname=bd_moteur_de_recherche; ', 'root', '' );
        $res=$bdd->prepare ( "SELECT Titre FROM corpus where " . implode(" or ", $kw)) ;
        $res->setFetchMode (PDO::FETCH_ASSOC) ;
        $res->execute ( ) ;
        $tab=$res->fetchAll( ) ;
        $afficher="oui";}
?>
<!DOCTYPE html>
<html>
<head>

<title>Moteur de recherche</title>
<meta charest="UTF-8" />
<link rel="stylesheet" href="style.css?t=<?php echo time( )?>" />
<meta name="viewport" content="width=device-width" />

</head>
<body>
<form name="fo" method="get" action="">
<input type="text" name="keywords" value="<?php echo $keywords ?>"  placeholder="Mots-cles" />
<input type="submit" name="valider" value="Rechercher" />

</form>
<?php if (@$afficher=="oui") { ?>
<div id="resultats">
<div id="nbr"><?=count ($tab) ." ". (count ($tab)>1?"résultats trouvés":"résultat trouvé")?></div>
<ol>
<?php for($i=0; $i<count ($tab) ; $i++) { ?>
<a href='Data science  fondamentaux et études de cas, Machine learning avec Python et R .pdf'><li><?php echo $tab[$i]["Titre"] ?></li></a>
<?php } ?>
</ol>
</div>
<?php } ?>
</body>
</html>

